public class Array5
{
	public static void main(String[] args) {
	  int arr[]=new int[] {68,90,97,104,120};
	  for(int i=0;i<arr.length;i++)
	  {
	      System.out.printf("%c ",arr[i]);
	  }
	}    
}