import java.util.Arrays;

public class Array6
{
	public static void main(String[] args) {
	  int arr[]=new int[] {68,90,97,104,120};
	  Arrays.sort(arr);
	  int ArrSize=arr.length;
	  for(int i=0;i<ArrSize;i++)
	  System.out.print(arr[i]+" ");
	  
	}    
}