public class flowControl7
{
	public static void main(String[] args) {
		char ch='a';
		if(ch>=65&&ch<=90){
		    System.out.println(ch+"->a");
		}else{
		    System.out.println(ch+"->A");
		}
	}
}