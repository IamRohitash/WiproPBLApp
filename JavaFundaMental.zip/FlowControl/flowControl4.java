public class flowControl4{
    public static void main(String[] args)
    {
        
        char char1='e';
        char char2='a';
        if(char1<char2)
        {
            System.out.println(char1+","+char2);
        }else{
            System.out.println(char2+","+char1);
        }
    }
}