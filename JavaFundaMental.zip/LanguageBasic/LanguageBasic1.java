public class LanguageBasic1
{
	public static void main(String[] args) {
	    String str1=args[0];
            String str1=args[1];
	    System.out.println(str1+" Technologies "+str2);
	}
}