public class LanguageBasic2
{
	public static void main(String[] args) {
	    String str1=args[0];
	    System.out.println"Welcome "+str1);
	}
}